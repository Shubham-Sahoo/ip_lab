### Spatial Filtering

### Steps to run the code

1) Open the Experiment Folder

2) compile using the command

g++ code/test.cpp `pkg-config --cflags --libs opencv`

3) run the executable ./a.out

4) To visualise the output images, move the slider of images/ filters/ kernel sizes.
	
